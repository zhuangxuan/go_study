package main

import "fmt"

func main() {
	//if 0 {
	//	fmt.Println("hello")
	//}

	//if nil {
	//	fmt.Println("hello")
	//}

	if true {
		fmt.Println("hello")
	}

	//a, b := 1, 2
	//x := a > b ? 0:-1
}
