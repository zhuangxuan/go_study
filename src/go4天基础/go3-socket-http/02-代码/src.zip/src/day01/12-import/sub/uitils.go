package sub

//package utils //不允许出现多个包名

import "fmt"

func test4() {
	fmt.Println("this is test4() in sub/utils!")
}
